#include "motor.h"

float motorDuty = 5.5f;

// ======================================================

void initMotor() {

  ledcAttach(
      BLDC_PWM_PIN,
      BLDC_PWM_FREQ,
      BLDC_PWM_RES
  );

  setMotorDuty(5.5f);
}

void setMotorDuty(float percent) {

  percent   = constrain(percent, 0.0f, 100.0f);
  motorDuty = percent;

  uint32_t maxPWM = (1 << BLDC_PWM_RES) - 1; // 4095
  uint32_t pwm    = (percent / 100.0f) * maxPWM;

  ledcWrite(BLDC_PWM_PIN, pwm);
}

void gradualMotorStop() {

  while (motorDuty > 5.5f) {

    motorDuty -= 0.2f;

    if (motorDuty < 5.5f)
      motorDuty = 5.5f;

    setMotorDuty(motorDuty);

    delay(300);
  }
}
