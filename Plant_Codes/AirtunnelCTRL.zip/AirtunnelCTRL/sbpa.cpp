#include "sbpa.h"
#include "settings.h"
#include "motor.h"
#include "logger.h"

uint8_t  sbpaVector[MAX_SBPA_SAMPLES];
int      numSamples       = 0;
bool     sbpaRunning      = false;
uint32_t sbpaStartTime    = 0;
uint32_t sbpaLastUpdate   = 0;
int      sbpaSampleIndex  = 0;

// ======================================================

void generateSBPA() {

  randomSeed(sbpaSeed);

  numSamples = identTimeMs / samplePeriodMs;

  if (numSamples > MAX_SBPA_SAMPLES) {

    numSamples = MAX_SBPA_SAMPLES;
  }

  for (int i = 0; i < numSamples; i++) {

    sbpaVector[i] = random(0, 2);
  }
}

void startSBPA() {

  generateSBPA();

  resetCSVFile();

  loggingEnabled             = true;
  sbpaRunning                = true;
  sbpaStartTime              = millis();
  identificationStartMillis  = millis();
  sbpaLastUpdate             = millis();
  sbpaSampleIndex            = 0;

  setMotorDuty(dutyHigh);
}

void stopSBPA() {

  sbpaRunning     = false;
  loggingEnabled  = false;

  flushLogBuffer();
}

void runSBPA() {

  if (!sbpaRunning)
    return;

  uint32_t now = millis();

  // Stabilization phase — hold at dutyHigh
  if ((now - sbpaStartTime) < stabilizationMs) {

    setMotorDuty(dutyHigh);

    return;
  }

  // Sequence exhausted
  if (sbpaSampleIndex >= numSamples) {

    sbpaRunning    = false;
    loggingEnabled = false;

    flushLogBuffer();

    setMotorDuty(dutyHigh);

    Serial.println("\nSBPA DONE!");
    
    return;
  }

  // Advance one sample
  if ((now - sbpaLastUpdate) >= samplePeriodMs) {

    sbpaLastUpdate = now;

    uint8_t bit = sbpaVector[sbpaSampleIndex];

    float duty = bit ? dutyHigh : dutyLow;

    setMotorDuty(duty);

    sbpaSampleIndex++;
  }
}

void printSBPAStatus() {

  Serial.println("\n=== SBPA_STATUS ===");
  Serial.print("HIGH=");      Serial.println(dutyHigh, 4);
  Serial.print("LOW=");       Serial.println(dutyLow, 4);
  Serial.print("SEED=");      Serial.println(sbpaSeed);
  Serial.print("IDENT_MS=");  Serial.println(identTimeMs);
  Serial.print("SAMPLE_MS="); Serial.println(samplePeriodMs);
  Serial.print("STAB_MS=");   Serial.println(stabilizationMs);
  Serial.println("====================");
}
