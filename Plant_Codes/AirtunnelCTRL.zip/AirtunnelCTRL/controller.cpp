#include "controller.h"
#include "settings.h"
#include "sensor.h"
#include "motor.h"

ControllerType activeController  = CONTROLLER_NONE;
bool           controllerEnabled = false;
bool           controllerTestMode = false;

// State
float pidError      = 0.0f;
float pidPrevError  = 0.0f;
float pidIntegral   = 0.0f;
float pidDerivative = 0.0f;
float pidOutput     = 5.5f;

// Reference
float controlReference = 300.0f;

// Timing
uint32_t lastControlUpdate = 0;

// Warmup duration (not persisted — tweak here if needed)
static const uint32_t WARMUP_TIME_MS = 5000;

// ======================================================

void initController() {

  pidIntegral    = 0.0f;
  pidPrevError   = 0.0f;
  pidDerivative  = 0.0f;
  pidOutput      = warmupPWM;
}

void controllerWarmup() {

  pidIntegral    = 0.0f;
  pidPrevError   = 0.0f;
  pidDerivative  = 0.0f;
  pidOutput      = warmupPWM;

  uint32_t warmupStart = millis();

  while ((millis() - warmupStart) < WARMUP_TIME_MS) {

    setMotorDuty(warmupPWM);

    float measurement = getFilteredDistance();

    switch (activeController) {

      case CONTROLLER_PID:
        runPID(controlReference, measurement);
        break;

      case CONTROLLER_P:
        runP(controlReference, measurement);
        break;

      default:
        break;
    }

    delay(controlPeriodMs);
  }
}

void updateController() {

  if (!controllerEnabled)
    return;

  uint32_t now = millis();

  if ((now - lastControlUpdate) < controlPeriodMs)
    return;

  lastControlUpdate = now;

  float measurement   = getFilteredDistance();
  float controlSignal = motorDuty;

  switch (activeController) {

    case CONTROLLER_PID:
      controlSignal = runPID(controlReference, measurement);
      break;

    case CONTROLLER_P:
      controlSignal = runP(controlReference, measurement);
      break;

    default:
      return;
  }

  controlSignal = constrain(
      controlSignal,
      controlOutputMin,
      controlOutputMax
  );

  pidOutput = controlSignal;

  if (!controllerTestMode) {

    setMotorDuty(controlSignal);
  }
}

float runPID(float reference, float measurement) {

  pidError      = reference - measurement;
  pidIntegral  += pidError;
  pidDerivative = pidError - pidPrevError;

  float output =
      (pidKp * pidError) +
      (pidKi * pidIntegral) +
      (pidKd * pidDerivative);

  pidPrevError  = pidError;
  pidOutput    += output;

  return pidOutput;
}

float runP(float reference, float measurement) {

  float error = reference - measurement;

  return warmupPWM + (pGain * error);
}

void setController(ControllerType type) {

  activeController = type;
}

void stopController() {

  controllerEnabled = false;
}

void printControllerStatus() {

  Serial.println("\n=== CTRL STATUS ===");

  Serial.print("Controller: ");

  switch (activeController) {

    case CONTROLLER_NONE: Serial.println("NONE"); break;
    case CONTROLLER_PID:  Serial.println("PID");  break;
    case CONTROLLER_P:    Serial.println("P");    break;
  }

  Serial.print("Reference: ");   Serial.println(controlReference);
  Serial.print("Output Min: ");  Serial.println(controlOutputMin);
  Serial.print("Output Max: ");  Serial.println(controlOutputMax);
  Serial.print("Warmup PWM: ");  Serial.println(warmupPWM);
  Serial.print("Control Period: "); Serial.println(controlPeriodMs);

  if (activeController == CONTROLLER_PID) {

    Serial.print("Kp: "); Serial.println(pidKp, 6);
    Serial.print("Ki: "); Serial.println(pidKi, 6);
    Serial.print("Kd: "); Serial.println(pidKd, 6);
  }

  if (activeController == CONTROLLER_P) {

    Serial.print("P Gain: "); Serial.println(pGain, 6);
  }

  Serial.println("====================");
}
