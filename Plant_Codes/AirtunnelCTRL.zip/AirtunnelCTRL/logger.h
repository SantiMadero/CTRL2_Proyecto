#pragma once
#include <Arduino.h>
#include <LittleFS.h>
#include "config.h"

// ======================================================
// LOGGER — RAM-buffered CSV writer to LittleFS
// ======================================================

struct LogEntry {
  uint32_t timeMs;
  float    pwm;
  float    height;
};

extern LogEntry  logBuffer[LOG_BUFFER_SIZE];
extern uint16_t  logIndex;
extern bool      loggingEnabled;
extern uint32_t  identificationStartMillis;

void initLogger();
void addLogEntry(float pwm, float height);
void flushLogBuffer();
void createCSVHeader();
void printCSVFile();
void resetCSVFile();
