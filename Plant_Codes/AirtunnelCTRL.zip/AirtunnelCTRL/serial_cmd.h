#pragma once

// ======================================================
// SERIAL_CMD — Command parser (call from loop)
// ======================================================

void processSerial();
