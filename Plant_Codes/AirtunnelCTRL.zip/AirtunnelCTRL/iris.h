#pragma once
#include <ESP32Servo.h>
#include "config.h"

// ======================================================
// IRIS — 360° continuous servo for aperture control
// ======================================================

extern Servo irisServo;

extern float         currentServoAngle;
extern float         targetServoAngle;
extern bool          servoMoving;
extern float         servoSpeedPercent;
extern unsigned long lastServoUpdate;

void initIris();
void stopServo();
void setServoDirection(float speed);  // speed: -1.0 (CCW) .. +1.0 (CW)
void updateServo();
