#pragma once

// ======================================================
// STATUS — Human-readable system state reporters
// ======================================================

void printStatus();
