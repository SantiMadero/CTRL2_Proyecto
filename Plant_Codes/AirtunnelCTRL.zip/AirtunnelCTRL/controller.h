#pragma once
#include <Arduino.h>

// ======================================================
// CONTROLLER — PID, P, and extensible controller types
// ======================================================

enum ControllerType {
  CONTROLLER_NONE = 0,
  CONTROLLER_PID,
  CONTROLLER_P
};

extern ControllerType activeController;
extern bool           controllerEnabled;
extern bool           controllerTestMode;

// Controller state
extern float pidError;
extern float pidPrevError;
extern float pidIntegral;
extern float pidDerivative;
extern float pidOutput;

// Reference
extern float controlReference;

// Timing
extern uint32_t lastControlUpdate;

void  initController();
void  updateController();       // call from loop()
float runPID(float reference, float measurement);
float runP  (float reference, float measurement);
void  setController(ControllerType type);
void  stopController();
void  controllerWarmup();
void  printControllerStatus();
