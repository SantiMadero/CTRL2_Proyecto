#pragma once
#include <Arduino.h>
#include "config.h"

// ======================================================
// SBPA — Symmetric Binary Pseudo-random signal
//         for open-loop plant identification
// ======================================================

extern uint8_t  sbpaVector[MAX_SBPA_SAMPLES];
extern int      numSamples;
extern bool     sbpaRunning;
extern uint32_t sbpaStartTime;
extern uint32_t sbpaLastUpdate;
extern int      sbpaSampleIndex;

void generateSBPA();
void startSBPA();
void stopSBPA();
void runSBPA();          // call from loop()
void printSBPAStatus();
