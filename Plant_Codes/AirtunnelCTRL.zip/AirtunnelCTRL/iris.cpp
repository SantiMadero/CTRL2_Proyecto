#include "iris.h"

Servo irisServo;

float         currentServoAngle  = 0.0f;
float         targetServoAngle   = 0.0f;
bool          servoMoving        = false;
float         servoSpeedPercent  = 100.0f;
unsigned long lastServoUpdate    = 0;

// ======================================================

void initIris() {

  irisServo.setPeriodHertz(50);

  irisServo.attach(
      SERVO_PIN,
      (int)SERVO_MIN_US,
      (int)SERVO_MAX_US
  );

  stopServo();
}

void stopServo() {

  irisServo.writeMicroseconds((int)SERVO_NEUTRAL_US);

  servoMoving = false;
}

void setServoDirection(float speed) {

  speed = constrain(speed, -1.0f, 1.0f);

  float us = SERVO_NEUTRAL_US + (speed * 500.0f);

  us = constrain(us, SERVO_MIN_US, SERVO_MAX_US);

  irisServo.writeMicroseconds((int)us);
}

void updateServo() {

  if (!servoMoving)
    return;

  unsigned long now = millis();

  float dt = (now - lastServoUpdate) / 1000.0f;

  lastServoUpdate = now;

  float direction =
      (targetServoAngle > currentServoAngle)
      ? 1.0f
      : -1.0f;

  float speedFactor = servoSpeedPercent / 100.0f;

  float deltaAngle =
      direction * MAX_SERVO_SPEED_DPS * speedFactor * dt;

  currentServoAngle += deltaAngle;

  if ((direction > 0 &&
       currentServoAngle >= targetServoAngle) ||
      (direction < 0 &&
       currentServoAngle <= targetServoAngle)) {

    currentServoAngle = targetServoAngle;

    stopServo();

    return;
  }

  setServoDirection(direction * speedFactor);
}
