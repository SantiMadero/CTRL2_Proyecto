#include "serial_cmd.h"
#include <Arduino.h>

#include "settings.h"
#include "motor.h"
#include "iris.h"
#include "sensor.h"
#include "sbpa.h"
#include "logger.h"
#include "controller.h"
#include "status.h"

// ======================================================
// COMMAND REFERENCE
// ======================================================
//
//  STATUS              — general system status
//  CTRL_STATUS         — active controller parameters
//  SBPA_STATUS         — SBPA configuration
//
//  MOTOR <pct>         — set motor duty cycle (%)
//  MOTOR_STOP          — gradual ramp-down to idle
//
//  CTRL <PID|P|NONE>   — select controller type
//  CTRL_ON             — enable + warmup controller
//  CTRL_OFF            — disable controller
//  TEST_ON / TEST_OFF  — detach output from actuator
//  KP <val>            — set PID Kp
//  KI <val>            — set PID Ki
//  KD <val>            — set PID Kd
//  PGAIN <val>         — set P gain
//  REF <val>           — set control reference (mm)
//  CTRL_MS <val>       — set control period (ms)
//  OUT_MIN <val>       — set output saturation min
//  OUT_MAX <val>       — set output saturation max
//  WARMUP_PWM <val>    — set warmup duty cycle
//
//  SBPA_START          — begin SBPA identification
//  SBPA_STOP           — abort SBPA
//  SBPA_HIGH <val>     — high duty threshold
//  SBPA_LOW  <val>     — low duty threshold
//  SEED <val>          — PRNG seed
//  IDENT_MS <val>      — total identification duration (ms)
//  SAMPLE_MS <val>     — SBPA sample period (ms)
//  STAB_MS <val>       — stabilization time before SBPA (ms)
//
//  LOG_START           — reset CSV and start logging
//  LOG_STOP            — stop logging and flush buffer
//  PRINT               — print CSV to serial
//  RESET               — wipe and re-create CSV
//
//  DEBUG <0|1>         — toggle sensor/control debug output
//
//  SERVO <angle>       — move iris to target angle
//  SERVO_SPEED <pct>   — set iris movement speed (%)
//  STOP                — stop iris servo
//
// ======================================================

void processSerial() {

  if (!Serial.available())
    return;

  String cmd = Serial.readStringUntil('\n');

  cmd.trim();

  // ---- STATUS ----------------------------------------

  if (cmd == "STATUS") {

    printStatus();
  }

  else if (cmd == "CTRL_STATUS") {

    printControllerStatus();
  }

  else if (cmd == "SBPA_STATUS") {

    printSBPAStatus();
  }

  // ---- MOTOR -----------------------------------------

  else if (cmd.startsWith("MOTOR ")) {

    setMotorDuty(cmd.substring(6).toFloat());
  }

  else if (cmd == "MOTOR_STOP") {

    gradualMotorStop();
  }

  // ---- CONTROLLER ------------------------------------

  else if (cmd == "CTRL_ON") {

    controllerEnabled  = true;
    lastControlUpdate  = millis();

    controllerWarmup();
  }

  else if (cmd == "CTRL_OFF") {

    stopController();
  }

  else if (cmd == "TEST_ON") {

    controllerTestMode = true;
  }

  else if (cmd == "TEST_OFF") {

    controllerTestMode = false;
  }

  else if (cmd.startsWith("CTRL ")) {

    String type = cmd.substring(5);
    type.trim();

    if      (type == "PID")  setController(CONTROLLER_PID);
    else if (type == "P")    setController(CONTROLLER_P);
    else if (type == "NONE") setController(CONTROLLER_NONE);
  }

  else if (cmd.startsWith("KP ")) {

    pidKp = cmd.substring(3).toFloat();
    saveSettings();
  }

  else if (cmd.startsWith("KI ")) {

    pidKi = cmd.substring(3).toFloat();
    saveSettings();
  }

  else if (cmd.startsWith("KD ")) {

    pidKd = cmd.substring(3).toFloat();
    saveSettings();
  }

  else if (cmd.startsWith("PGAIN ")) {

    pGain = cmd.substring(6).toFloat();
    saveSettings();
  }

  else if (cmd.startsWith("REF ")) {

    controlReference = cmd.substring(4).toFloat();
  }

  else if (cmd.startsWith("CTRL_MS ")) {

    controlPeriodMs = cmd.substring(8).toInt();
    saveSettings();
  }

  else if (cmd.startsWith("OUT_MIN ")) {

    controlOutputMin = cmd.substring(8).toFloat();
    saveSettings();
  }

  else if (cmd.startsWith("OUT_MAX ")) {

    controlOutputMax = cmd.substring(8).toFloat();
    saveSettings();
  }

  else if (cmd.startsWith("WARMUP_PWM ")) {

    warmupPWM = cmd.substring(11).toFloat();
    saveSettings();
  }

  // ---- SBPA ------------------------------------------

  else if (cmd == "SBPA_START") {

    startSBPA();
  }

  else if (cmd == "SBPA_STOP") {

    stopSBPA();
  }

  else if (cmd.startsWith("SBPA_HIGH ")) {

    dutyHigh = cmd.substring(10).toFloat();
    saveSettings();
  }

  else if (cmd.startsWith("SBPA_LOW ")) {

    dutyLow = cmd.substring(9).toFloat();
    saveSettings();
  }

  else if (cmd.startsWith("SEED ")) {

    sbpaSeed = cmd.substring(5).toInt();
    saveSettings();
  }

  else if (cmd.startsWith("IDENT_MS ")) {

    identTimeMs = cmd.substring(9).toInt();
    saveSettings();
  }

  else if (cmd.startsWith("SAMPLE_MS ")) {

    samplePeriodMs = cmd.substring(10).toInt();
    saveSettings();
  }

  else if (cmd.startsWith("STAB_MS ")) {

    stabilizationMs = cmd.substring(8).toInt();
    saveSettings();
  }

  // ---- LOGGING ---------------------------------------

  else if (cmd == "LOG_START") {

    resetCSVFile();
    identificationStartMillis = millis();
    loggingEnabled            = true;
  }

  else if (cmd == "LOG_STOP") {

    loggingEnabled = false;
    flushLogBuffer();
  }

  else if (cmd == "PRINT") {

    printCSVFile();
  }

  else if (cmd == "RESET") {

    resetCSVFile();
  }

  // ---- DEBUG -----------------------------------------

  else if (cmd.startsWith("DEBUG ")) {

    sensorDebug = (bool)cmd.substring(6).toInt();
    saveSettings();
  }

  // ---- SERVO -----------------------------------------

  else if (cmd.startsWith("SERVO_SPEED ")) {

    servoSpeedPercent = cmd.substring(12).toFloat();
  }

  else if (cmd.startsWith("SERVO ")) {

    targetServoAngle = cmd.substring(6).toFloat();
    servoMoving      = true;
    lastServoUpdate  = millis();
  }

  else if (cmd == "STOP") {

    stopServo();
  }
}
