#include "settings.h"

Preferences prefs;

// SBPA defaults
float    dutyHigh       = 7.10f;
float    dutyLow        = 6.86f;
uint32_t sbpaSeed       = 12345;
uint32_t identTimeMs    = 20000;
uint32_t samplePeriodMs = 100;
uint32_t stabilizationMs = 2000;

// Debug
bool sensorDebug = true;

// PID
float pidKp = 0.01f;
float pidKi = 0.0005f;
float pidKd = 0.0f;

// P
float pGain = 0.0085f;

// Controller config
uint32_t controlPeriodMs  = 20;
float    warmupPWM        = 7.15f;
float    controlOutputMin = 5.5f;
float    controlOutputMax = 8.0f;

// ======================================================

void saveSettings() {

  prefs.putFloat("dHigh",  dutyHigh);
  prefs.putFloat("dLow",   dutyLow);
  prefs.putULong("seed",   sbpaSeed);
  prefs.putULong("ident",  identTimeMs);
  prefs.putULong("sample", samplePeriodMs);
  prefs.putULong("stab",   stabilizationMs);
  prefs.putBool ("debug",  sensorDebug);
  prefs.putFloat("kp",     pidKp);
  prefs.putFloat("ki",     pidKi);
  prefs.putFloat("kd",     pidKd);
  prefs.putFloat("pgain",  pGain);
  prefs.putULong("ctrlms", controlPeriodMs);
  prefs.putFloat("warmup", warmupPWM);
  prefs.putFloat("outmin", controlOutputMin);
  prefs.putFloat("outmax", controlOutputMax);
}

void loadSettings() {

  dutyHigh        = prefs.getFloat("dHigh",  7.10f);
  dutyLow         = prefs.getFloat("dLow",   6.86f);
  sbpaSeed        = prefs.getULong("seed",   12345);
  identTimeMs     = prefs.getULong("ident",  20000);
  samplePeriodMs  = prefs.getULong("sample", 100);
  stabilizationMs = prefs.getULong("stab",   2000);
  sensorDebug     = prefs.getBool ("debug",  true);
  pidKp           = prefs.getFloat("kp",     0.01f);
  pidKi           = prefs.getFloat("ki",     0.0005f);
  pidKd           = prefs.getFloat("kd",     0.0f);
  pGain           = prefs.getFloat("pgain",  0.0085f);
  controlPeriodMs = prefs.getULong("ctrlms", 20);
  warmupPWM       = prefs.getFloat("warmup", 7.15f);
  controlOutputMin = prefs.getFloat("outmin", 5.5f);
  controlOutputMax = prefs.getFloat("outmax", 8.0f);
}
