#pragma once
#include <Arduino.h>
#include "config.h"

// ======================================================
// MOTOR — BLDC via ESC PWM drive
// ======================================================

extern float motorDuty;

void initMotor();
void setMotorDuty(float percent);
void gradualMotorStop();
