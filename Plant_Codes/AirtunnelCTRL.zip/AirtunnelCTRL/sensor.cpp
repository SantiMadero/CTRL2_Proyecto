#include "sensor.h"

VL53L0X tof;

float   distanceBuffer[FILTER_SIZE] = {0};
uint8_t bufferIndex  = 0;
bool    bufferFilled = false;

// ======================================================

void initSensor() {

  Wire.begin(I2C_SDA, I2C_SCL);

  tof.setTimeout(500);

  if (tof.init()) {

    tof.startContinuous();
  }
}

float getFilteredDistance() {

  uint16_t raw =
      tof.readRangeContinuousMillimeters();

  if (tof.timeoutOccurred()) {

    return -1;
  }

  // Linear correction calibrated for this tunnel
  float corrected =
      (1.430977f * raw) - 135.655228f;

  distanceBuffer[bufferIndex] = corrected;

  bufferIndex++;

  if (bufferIndex >= FILTER_SIZE) {

    bufferIndex  = 0;
    bufferFilled = true;
  }

  uint8_t count =
      bufferFilled ? FILTER_SIZE : bufferIndex;

  if (count == 0)
    return corrected;

  float sum = 0;

  for (int i = 0; i < count; i++) {

    sum += distanceBuffer[i];
  }

  return sum / count;
}
