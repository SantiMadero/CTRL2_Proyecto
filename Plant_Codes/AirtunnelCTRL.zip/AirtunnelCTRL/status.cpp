#include "status.h"
#include <Arduino.h>
#include "motor.h"
#include "sensor.h"
#include "controller.h"

// ======================================================

void printStatus() {

  Serial.println("\n=== STATUS ===");

  Serial.print("Motor Duty: ");
  Serial.println(motorDuty);

  Serial.print("Height: ");
  Serial.println(getFilteredDistance());

  Serial.print("Controller Enabled: ");
  Serial.println(controllerEnabled ? "YES" : "NO");

  Serial.print("Test Mode: ");
  Serial.println(controllerTestMode ? "YES" : "NO");

  Serial.print("Controller Output: ");
  Serial.println(pidOutput);

  Serial.println("================");
}
