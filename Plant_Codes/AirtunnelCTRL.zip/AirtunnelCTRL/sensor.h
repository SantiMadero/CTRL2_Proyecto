#pragma once
#include <Wire.h>
#include <VL53L0X.h>
#include "config.h"

// ======================================================
// SENSOR — VL53L0X distance measurement + moving average
// ======================================================

extern VL53L0X tof;

extern float   distanceBuffer[FILTER_SIZE];
extern uint8_t bufferIndex;
extern bool    bufferFilled;

void  initSensor();
float getFilteredDistance();
