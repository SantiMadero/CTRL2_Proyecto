#pragma once
#include <Preferences.h>

// ======================================================
// SETTINGS — Persisted via NVS Preferences
// ======================================================

extern Preferences prefs;

// SBPA
extern float    dutyHigh;
extern float    dutyLow;
extern uint32_t sbpaSeed;
extern uint32_t identTimeMs;
extern uint32_t samplePeriodMs;
extern uint32_t stabilizationMs;

// Debug / logging
extern bool sensorDebug;

// PID gains
extern float pidKp;
extern float pidKi;
extern float pidKd;

// P gain
extern float pGain;

// Controller config
extern uint32_t controlPeriodMs;
extern float    warmupPWM;
extern float    controlOutputMin;
extern float    controlOutputMax;

void saveSettings();
void loadSettings();
