#include "logger.h"
#include "sbpa.h"   // for printSBPAStatus() appended to CSV

LogEntry logBuffer[LOG_BUFFER_SIZE];
uint16_t logIndex                  = 0;
bool     loggingEnabled            = false;
uint32_t identificationStartMillis = 0;

// ======================================================

void initLogger() {

  LittleFS.begin(true);

  if (!LittleFS.exists("/plant_data.csv")) {

    createCSVHeader();
  }
}

void addLogEntry(float pwm, float height) {

  uint32_t relativeTime =
      millis() - identificationStartMillis;

  logBuffer[logIndex].timeMs = relativeTime;
  logBuffer[logIndex].pwm    = pwm;
  logBuffer[logIndex].height = height;

  logIndex++;

  if (logIndex >= LOG_BUFFER_SIZE) {

    flushLogBuffer();
  }
}

void flushLogBuffer() {

  File file =
      LittleFS.open("/plant_data.csv", "a");

  if (!file)
    return;

  for (int i = 0; i < logIndex; i++) {

    file.print(logBuffer[i].timeMs);
    file.print(",");
    file.print(logBuffer[i].pwm, 3);
    file.print(",");
    file.println(logBuffer[i].height, 3);
  }

  file.close();

  logIndex = 0;
}

void createCSVHeader() {

  File file =
      LittleFS.open("/plant_data.csv", "w");

  if (file) {

    file.println("time_ms,pwm,height_mm");

    file.close();
  }
}

void printCSVFile() {

   // Append SBPA configuration metadata
  printSBPAStatus();

  if (logIndex > 0) {

    flushLogBuffer();
  }

  File file =
      LittleFS.open("/plant_data.csv", "r");

  if (!file)
    return;

  while (file.available()) {

    Serial.write(file.read());
  }

  file.close();
}

void resetCSVFile() {

  LittleFS.remove("/plant_data.csv");

  createCSVHeader();

  logIndex = 0;
}
