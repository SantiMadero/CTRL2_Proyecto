/*
   ESP32-S3 WIND TUNNEL CONTROLLER
   --------------------------------

   File layout
   -----------
   config.h        — pin defs, PWM settings, compile-time constants
   settings.h/cpp  — NVS Preferences load/save (persists across power cycles)
   sensor.h/cpp    — VL53L0X init, moving-average filter
   motor.h/cpp     — BLDC PWM drive, gradual stop
   iris.h/cpp      — 360° continuous servo (iris aperture)
   sbpa.h/cpp      — SBPA signal generation & playback
   logger.h/cpp    — RAM-buffered CSV logging to LittleFS
   controller.h/cpp— PID, P controllers + warmup + test mode
   status.h/cpp    — STATUS / CTRL_STATUS reporters
   serial_cmd.h/cpp— Serial command parser (see serial_cmd.cpp for full list)
   AirtunnelCTRL.ino — setup() / loop()
*/

#include <Arduino.h>

#include "config.h"
#include "settings.h"
#include "sensor.h"
#include "motor.h"
#include "iris.h"
#include "logger.h"
#include "sbpa.h"
#include "controller.h"
#include "serial_cmd.h"

// Timing globals for debug output and loop logging
static unsigned long lastSensorPrint = 0;
static unsigned long lastLogTime     = 0;

// ======================================================
// SETUP
// ======================================================

void setup() {

  Serial.begin(115200);

  // NVS — must open before loadSettings()
  prefs.begin("windTunnel", false);
  loadSettings();

  // Subsystem init
  initLogger();      // LittleFS + CSV header
  initMotor();       // LEDC PWM, idle at 5.5 %
  initSensor();      // Wire + VL53L0X
  initIris();        // Servo attach + neutral
  initController();  // Reset integrator state

  Serial.println("SYSTEM READY");
}

// ======================================================
// LOOP
// ======================================================

void loop() {

  processSerial();

  updateServo();

  runSBPA();

  updateController();

  float dist = getFilteredDistance();

  // --- debug stream — Serial Plotter friendly ----------
  // Labels use the "Label:value" format recognised by the
  // Arduino Serial Plotter (Tools → Serial Plotter).
  // Channels: Reference | Measurement | Error | Control

  if (sensorDebug &&
      (millis() - lastSensorPrint) > 20) {

    lastSensorPrint = millis();

    float plotError = controlReference - dist;

    Serial.print("Reference:");
    Serial.print(controlReference);
    Serial.print(",Measurement:");
    Serial.print(dist);
    Serial.print(",Error:");
    Serial.print(plotError);
    Serial.print(",Control:");
    Serial.println(pidOutput);
  }

  // --- periodic CSV logging ---------------------------

  if (loggingEnabled &&
      (millis() - lastLogTime) > 20) {

    lastLogTime = millis();

    addLogEntry(motorDuty, dist);
  }
}
